<?php
use Illuminate\Support\Facades\Route;

Route::post('/cashfree/response','CheckoutController@cashfreeSuccess');