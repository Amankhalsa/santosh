<?php

namespace App\Admin_model;

use Illuminate\Database\Eloquent\Model;

class manage_page extends Model
{
    //
}
