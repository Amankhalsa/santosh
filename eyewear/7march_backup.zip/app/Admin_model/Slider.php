<?php

namespace App\admin_model;

use Illuminate\Database\Eloquent\Model;

class Slider extends Model
{
    protected $fillable = ['slider_image_name','slider_title1','slider_status'];
}
