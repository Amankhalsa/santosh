<?php

namespace App\admin_model;

use Illuminate\Database\Eloquent\Model;

class Our_brand extends Model
{
    protected $fillable = ['brand_image'];
}
