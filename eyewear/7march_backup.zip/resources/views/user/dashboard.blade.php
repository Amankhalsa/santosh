@extends('user.layouts.app')

@section('user-content')
 
<center> 
<h3>Welcome to your dashboard</h3>

<p>You can manage your account details and check order history from here.</p>
</center>

@endsection