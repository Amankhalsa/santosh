@extends('layouts.app')

@section('content')
<div class=" " style="text-align: center;
    margin: 150px;">
 <i class="fa fa-times-circle" style="font-size:48px;color: #ff9933;"></i><h3>  Oops!</h3>
<h5>Your payment has been cancelled !</h5>
</div>
@endsection