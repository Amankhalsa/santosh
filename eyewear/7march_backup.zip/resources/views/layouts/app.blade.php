@include('layouts.header')
@include('layouts.header-top')

@include('layouts.navbar_new')
<div >
  @yield('content')
</div>
@include('layouts.footer')
