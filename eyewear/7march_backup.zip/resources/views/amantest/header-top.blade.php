

<!--

  <div class="wsmobileheader clearfix ">
    <a id="wsnavtoggle" class="wsanimated-arrow"><span></span></a>
    <span class="smllogo"><img src="{{asset('uploaded_files/logo/'.$admin_data->admin_logo)}}" width="80" alt="" /></span>
    <!--<a href="tel:{{$admin_data->admin_mobile}}" class="callusbtn"><i class="fas fa-phone-alt"></i></a>-->
  </div>
  

<!--
  <div class="headtoppart clearfix">
    <div class="headerwp clearfix">
      <div class="headertopleft">
        <div class="address clearfix"><a href="#"><i class="fas fa-phone fa-flip-horizontal"></i> {{$admin_data->admin_mobile}}</a></div>
      </div>
      <div class="headertopright">
       @if(!empty($admin_data->admin_youtube_link)) 
        <a class="googleicon" title="Youtube" href="{{$admin_data->admin_youtube_link}}"><i class="fab fa-youtube"></i> <span
            class="mobiletext02">Youtube</span></a>
       @endif   
       @if(!empty($admin_data->admin_linkedin_link))
        <a class="linkedinicon" title="Linkedin" href="{{$admin_data->admin_linkedin_link}}"><i class="fab fa-linkedin-in"></i> <span
            class="mobiletext02">Linkedin</span></a>
       @endif 
       @if(!empty($admin_data->admin_instagram_link)) 
        <a class="googleicon" title="Instagram" href="{{$admin_data->admin_instagram_link}}"><i class="fab fa-instagram"></i> <span
            class="mobiletext02">Instagram</span></a>
       @endif
       @if(!empty($admin_data->admin_twitter_link))     
        <a class="twittericon" title="Twitter" href="{{$admin_data->admin_twitter_link}}"><i class="fab fa-twitter"></i> <span
            class="mobiletext02">Twitter</span></a>
       @endif 
       @if(!empty($admin_data->admin_facebook_link))     
        <a class="facebookicon" title="Facebook" href="{{$admin_data->admin_facebook_link}}"><i class="fab fa-facebook-f"></i> <span
            class="mobiletext02">Facebook</span></a>
       @endif     
      </div>
    </div>
  </div>
  -->
