<?php

namespace App\admin_model;

use Illuminate\Database\Eloquent\Model;

class OurClient extends Model
{
    protected $fillable = ['client_image_name'];
}
