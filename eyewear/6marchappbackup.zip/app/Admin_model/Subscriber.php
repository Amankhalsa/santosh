<?php

namespace App\Admin_model;

use Illuminate\Database\Eloquent\Model;

class Subscriber extends Model
{
    protected $fillable =['subscriber_email'];
}
