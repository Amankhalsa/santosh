
@include('amantest.header')

@include('amantest.navbar_old')
<div>

  @yield('content')


</div>
  <marquee width="90%" direction="up" height="100px">
        <h1 class="text-center">This is a sample page for Testing</h1>

</marquee>
@include('amantest.footer')