@extends('layouts.app')

@section('content')
<div class=" " style="text-align: center;
    margin: 150px;">
 <i class="fa fa-check-square" style="font-size:48px;color: #ff9933;"></i><h3>  Thankyou</h3>
<h5>Your order has been placed successfully !</h5>
</div>
@endsection