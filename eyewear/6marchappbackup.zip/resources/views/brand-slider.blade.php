  <section>
    <div class="brand_logo_section">
      <div class="container">
        <div class="brand_swiper_img">
          <div class="swiper logoSwiper">
<div class="swiper-wrapper">
  <div class="swiper-slide"><img src="{{asset('uploaded_files/assets/images/brand_logo_1.png')}}" alt="Image Not Found"></div>
  <div class="swiper-slide"><img src="{{asset('uploaded_files/assets/images/brand_logo_2.png')}}" alt="Image Not Found"></div>
  <div class="swiper-slide"><img src="{{asset('uploaded_files/assets/images/brand_logo_3.png')}}" alt="Image Not Found"></div>
  <div class="swiper-slide"><img src="{{asset('uploaded_files/assets/images/brand_logo_4.png')}}" alt="Image Not Found"></div>
  <div class="swiper-slide"><img src="{{asset('uploaded_files/assets/images/brand_logo_5.png')}}" alt="Image Not Found"></div>
  <div class="swiper-slide"><img src="{{asset('uploaded_files/assets/images/brand_logo_3.png')}}" alt="Image Not Found"></div>
  <div class="swiper-slide"><img src="{{asset('uploaded_files/assets/images/brand_logo_2.png')}}" alt="Image Not Found"></div>
            </div>
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
            <!-- <div class="swiper-pagination"></div> -->
          </div>
        </div>
      </div>
    </div>
  </section>
  
  <!--main section start-->
   