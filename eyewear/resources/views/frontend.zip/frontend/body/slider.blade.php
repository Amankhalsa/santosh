<section>
    <div class="bannerCol">
      <div class="container-fluid p-0">
        <div class="bannerSlider">
          <div class="swiper bannerSlider swiperStyle">
            <div class="swiper-wrapper">
              <div class="swiper-slide">
                <div class="swiper_bg_img" style="background-image: url('assets/images/Aman.png');">
                  <div class="container">
                    <div class="bannerImgCnt">
                      <a href="javascript:void(0)"><img src="{{asset('assets/images/Aman.png')}}" alt="..." class="saleImg"></a>
                    </div>
                  </div>
                </div>
              </div>
              <div class="swiper-slide active">
                <div class="swiper_bg_img" style="background-image: url('assets/images/banner_img.jpg');">
                  <div class="container">
                    <div class="bannerImgCnt">
                      <a href="javascript:void(0)"><img src="{{asset('assets/images/banner-content.png')}}" alt="..." class="saleImg"></a>
                    </div>
                  </div>
                </div>
              </div>
              <div class="swiper-slide">
                <div class="swiper_bg_img" style="background-image: url('assets/images/banner_img.jpg');">
                  <div class="container">
                    <div class="bannerImgCnt">
                      <a href="javascript:void(0)"><img src="{{asset('assets/images/banner-content.png')}}" alt="..." class="saleImg"></a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="swiper-pagination"></div>
          </div>
        </div>
      </div>
    </div>
  </section>